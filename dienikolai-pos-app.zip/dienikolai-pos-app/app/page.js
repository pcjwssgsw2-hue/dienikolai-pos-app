export default function Home() {
  return (
    <main style={{padding: 40, fontFamily: 'Arial'}}>
      <h1>Salon Bestandsaufnahme</h1>
      <p>Die App wurde erfolgreich erstellt.</p>

      <div style={{
        marginTop: 20,
        padding: 20,
        border: '1px solid #ccc',
        borderRadius: 10
      }}>
        <h2>Produkte</h2>

        <ul>
          <li>Shampoo – 12 Stück</li>
          <li>Conditioner – 8 Stück</li>
          <li>Haaröl – 5 Stück</li>
        </ul>
      </div>
    </main>
  )
}
