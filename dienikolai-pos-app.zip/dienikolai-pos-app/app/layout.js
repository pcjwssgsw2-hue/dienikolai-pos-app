export const metadata = {
  title: 'Salon Bestandsaufnahme',
  description: 'Inventur-App'
}

export default function RootLayout({ children }) {
  return (
    <html lang="de">
      <body>{children}</body>
    </html>
  )
}
