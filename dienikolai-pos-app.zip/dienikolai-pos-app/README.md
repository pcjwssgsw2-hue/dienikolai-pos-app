# Salon Bestandsaufnahme App

Starten:
npm install
npm run dev
